package cB.genericUtility;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.NumberToTextConverter;

public class ExcelUtility {
	
	/*
	 * Read String data from Excel
	 */
	public String readStringDataFromExcel(String sheetName,int rowNum,int cellNum) throws EncryptedDocumentException, IOException
	{
		FileInputStream fileInputStream=new FileInputStream("./src/test/resource/demo.xlsx");
		Workbook workbook=WorkbookFactory.create(fileInputStream);
//		Sheet sheet=wb.getSheet(sheetName);
//		Row row=sheet.getRow(rowNum);
//      org.apache.poi.ss.usermodel.Cell cell = row.getCell(cellNum);
//		String strValue = cell.getStringCellValue();
		String strValue=workbook.getSheet(sheetName).getRow(rowNum).getCell(cellNum).getStringCellValue();
		return strValue;
	}
	
	/*
	 * Read numeric data from excel
	 */
	public String readNumericDataFromExcel(String sheetName,int rowNum,int cellNum) throws EncryptedDocumentException, IOException
	{
		FileInputStream fileInputStream=new FileInputStream("./src/test/resource/demo.xlsx");
		Workbook workbook=WorkbookFactory.create(fileInputStream);
//		Sheet sheet=wb.getSheet(sheetName);
//		Row row=sheet.getRow(rowNum);
//      org.apache.poi.ss.usermodel.Cell cell = row.getCell(cellNum);
//      long numValue =(long)cell.getNumericCellValue();
		String numValue=NumberToTextConverter.toText(workbook.getSheet(sheetName).getRow(rowNum).getCell(cellNum).getNumericCellValue());
		return numValue;
	}
}
