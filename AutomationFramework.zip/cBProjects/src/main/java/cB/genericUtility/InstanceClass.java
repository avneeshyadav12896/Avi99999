  package cB.genericUtility;

import org.openqa.selenium.WebDriver;

import cB.pomrepo.HomePage;
import cB.pomrepo.LoginPage;

public class InstanceClass {
    
	public WebDriver driver;
	public ExcelUtility excelUtility;
	public FileUtility fileUtility;
	public WebDriverUtility webDriverUtility;
	public JavaUtility javaUtility;
	public ExtentReportNG extentReport;
	public IListener iListener;
	
	protected String url;
	protected String browser;
	protected String username;
	protected String password;
	protected long longTimeout;
	
	public HomePage homePage;
	public LoginPage loginPage;

}

