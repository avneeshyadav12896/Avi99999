package cB.genericUtility;

import java.io.IOException;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import cB.pomrepo.HomePage;
import cB.pomrepo.LoginPage;

public class BaseClass extends InstanceClass{
	
	@BeforeClass
	public void suiteSetUp() throws IOException {
		fileUtility=new FileUtility();
		javaUtility=new JavaUtility();
		excelUtility=new ExcelUtility();
		webDriverUtility=new WebDriverUtility();
		extentReport=new ExtentReportNG();
		iListener=new IListener();		
		url=fileUtility.readDataFromPropertyFile("url");
		browser=fileUtility.readDataFromPropertyFile("browser");
		driver=webDriverUtility.setupBrowser(browser);
		webDriverUtility.maximizeBrowser();
		webDriverUtility.openApplication(url);		
		loginPage=new LoginPage(driver);
		homePage=new HomePage(driver);

	}

	@AfterClass
	public void executeAfterClass() throws InterruptedException
	{
		Thread.sleep(2000);
		driver.close();
	}
}
