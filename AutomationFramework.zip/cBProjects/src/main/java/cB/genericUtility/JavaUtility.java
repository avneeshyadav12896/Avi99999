package cB.genericUtility;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import org.apache.poi.ss.util.NumberToTextConverter;

import com.github.javafaker.Faker;

public final class JavaUtility {
	/**
	 * This class contains java reusable methods
	 * @author rakes
	 *
	 */
		/**
		 * The method is used to generate the random number
		 * @return
		 */

	Faker faker;
		public int getRandomNumber() {
			return new Random().nextInt(100);
		}
		/**
		 * The method is used to generate the random number with in limit
		 * @parameter limit
		 * @return
		 */
		public int getRandomNumber(int limit) {
			return new Random().nextInt(limit);
		}
		/**
		 * This method is used to convert the String to long data type
		 * @parameter stringData
		 * @return
		 */
		public long convertStringToLong(String stringData) {
			return Long.parseLong(stringData);
		}
		/**
		 * This method is used to print a statement
		 * @parameter value
		 */
		public void printStatement(String value) {
			System.out.println(value);
		}
		/**
		 * This method is used to split the string based on strategy
		 * @parameter value
		 * @parameter strategy
		 * @return
		 */
		public String[] splitString(String value,String strategy) {
			return value.split(strategy);
		}
		/**
		 * This method is used to get current data in specified strategy 
		 * @parameter strategy
		 * @return
		 */
		public String getCurrentDate(String strategy) {
			return new SimpleDateFormat(strategy).format(new Date());
		}
		
		/*
		 * This method is used to get random First Name of user
		 * 
		 */
		public String getFirstName()
		{
			Faker faker=new Faker();
			return faker.name().firstName();
		}
		/*
		 * This method is used to get random Last Name of user
		 * 
		 */
		public String getLastName()
		{
			Faker faker=new Faker();
			return faker.name().lastName();
		}
		/*
		 * This method is used to get random email address
		 * 
		 */
		public String getEmailAddress()
		{
			Faker faker=new Faker();
			return faker.internet().emailAddress();
		}
		/*
		 * This method is used to get random address
		 * 
		 */
		public String getAddress()
		{
			Faker faker=new Faker();
			return faker.address().fullAddress();
		}
		/*
		 * This method is used to get random mobile number
		 */
		public String getMobileNumber()
		{
			Faker faker = new Faker();
			return faker.phoneNumber().phoneNumber();
		}
	
		/*
		 * This method is used to get the random OTP 6 digit
		 */
		public String randomOTP4()
		{
			int otp=new Random().nextInt(500)+1234;
			String randomOTP4 = NumberToTextConverter.toText(otp);
			return randomOTP4;
		}
		/*
		/*
		 * This method is used to get the random OTP 4 digit
		 */
		public String randomOTP6()
		{
			int otp=new Random().nextInt(500)+123456;
			String randomOTP6 = NumberToTextConverter.toText(otp);
			return randomOTP6;
		}
		/*
		 * This method is used to get the random mobile number
		 */
		public String randomMobileNumber()
		{
			int mobile=new Random().nextInt(50000)+1234567890;
			String mobileNumber = NumberToTextConverter.toText(mobile);
			return mobileNumber;
		}
		/*
		 * This method is used to get the int random number
		 */
		public int randomNumber(int a)
		{
			Random random=new Random();
			int randomNo = random.nextInt(101);
			return randomNo;
		}

		/*
	     * This method is used to get random String
	     */
		public  String randomString() 
		{
			 int length = 10; // Length of the random string
			 String randomString = generateRandomString(length);
			 return randomString;
//			 System.out.println("Random string: " + randomString);
		}
		/*
		 * 
		 */
		public  String generateRandomString(int length) 
		{
		     StringBuilder sb = new StringBuilder(length);
		     Random random = new Random();
			 String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
			 for (int i = 0; i < length; i++) {
			      int randomIndex = random.nextInt(CHARACTERS.length());
			      sb.append(CHARACTERS.charAt(randomIndex));
			      }
			       return sb.toString();
		}
		/*
		 * This method used to generate random gmail
		 */
		public String randomEmail()
		{
			 int length = 10; // Length of the random string
			 String randomString = generateRandomString(length)+"@gmail.com";
			 return randomString;
		
		}

		/*
		 * This method is used to generate ranmdom addhar number
		 */
		public String getRandomAadhaarNumber() 
		{
//		        Faker faker = new Faker();
		        Random random = new Random();
		        StringBuilder aadhaarNumber = new StringBuilder();

		        // Generate first 11 digits randomly
		        for (int i = 0; i < 11; i++) {
		            int digit = random.nextInt(10);
		            aadhaarNumber.append(digit);
		        }

		        // Calculate checksum digit using Verhoeff algorithm
		        int checksumDigit = calculateVerhoeffChecksum(aadhaarNumber.toString());
		        aadhaarNumber.append(checksumDigit);

		        return aadhaarNumber.toString();
		    }

		
		    private static int calculateVerhoeffChecksum(String number) {
		        // Verhoeff algorithm implementation to calculate checksum
		        int[][] d = {
		            {0, 1, 2, 3, 4, 5, 6, 7, 8, 9},
		            {1, 2, 3, 4, 0, 6, 7, 8, 9, 5},
		            {2, 3, 4, 0, 1, 7, 8, 9, 5, 6},
		            {3, 4, 0, 1, 2, 8, 9, 5, 6, 7},
		            {4, 0, 1, 2, 3, 9, 5, 6, 7, 8},
		            {5, 9, 8, 7, 6, 0, 4, 3, 2, 1},
		            {6, 5, 9, 8, 7, 1, 0, 4, 3, 2},
		            {7, 6, 5, 9, 8, 2, 1, 0, 4, 3},
		            {8, 7, 6, 5, 9, 3, 2, 1, 0, 4},
		            {9, 8, 7, 6, 5, 4, 3, 2, 1, 0}
		        };

		        int[][] p = {
		            {0, 1, 2, 3, 4, 5, 6, 7, 8, 9},
		            {1, 5, 7, 6, 2, 8, 3, 0, 9, 4},
		            {5, 8, 0, 3, 7, 9, 6, 1, 4, 2},
		            {8, 9, 1, 6, 0, 4, 3, 5, 2, 7},
		            {9, 4, 5, 3, 1, 2, 6, 8, 7, 0},
		            {4, 2, 8, 6, 5, 7, 3, 9, 0, 1},
		            {2, 7, 9, 3, 8, 0, 6, 4, 1, 5},
		            {7, 0, 4, 6, 9, 1, 3, 2, 5, 8}
		        };

		        int[] inv = {0, 4, 3, 2, 1, 5, 6, 7, 8, 9};

		        int c = 0;
		        int[] myArray = StringToReversedIntArray(number);

		        for (int i = 0; i < myArray.length; i++) {
		            c = d[c][p[(i % 8)][myArray[i]]];
		        }

		        return inv[c];
		    }

		    private static int[] StringToReversedIntArray(String number) {
		        int[] myArray = new int[number.length()];

		        for (int i = 0; i < number.length(); i++) {
		            myArray[i] = Integer.parseInt(number.substring(i, i + 1));
		        }

		        return myArray;
		    }
		

}
