package cB.genericUtility;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


/**
 * This Class Contains all the web driver action
 * 
 * @author "Avneesh Yadav"
 *
 */
public final class WebDriverUtility {

	public WebDriver driver;
	public WebDriverWait wait;
	public Actions action;

	/**
	 * This method is used to setup driver instance
	 * 
	 * @parameter browser
	 * @return
	 */
	public WebDriver setupBrowser(String browser) {

		switch (browser) {
		case "chrome":
			driver = new ChromeDriver();
			break;
			
		case "firefox":	
			driver = new FirefoxDriver();
			break;
			
		case "edge":
			driver = new InternetExplorerDriver();
			break;

		default:
			System.out.println("Entered wrong browser key in the Property file");
			break;
		}
		return driver;
	}

	/*
	 * this method is use to setup driver
	 */
	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	/**
	 * This method is used to maximize the browser
	 */
	public void maxmizeBrowser() {
		driver.manage().window().maximize();
	}

	/**
	 * This method is used to wait the page by using Implicit wait
	 * 
	 * @parameter driver2
	 */
	public void implicitWait(WebDriver driver) {

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	
	/**
	 * This method is used to wait the page by using implicit wait
	 * @param longTimeout
	 */

	public void implicitWait(long longTimeout) {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(longTimeout));
	}

	/**
	 * This method is used to navigate the application
	 * 
	 * @parameter url
	 */
	public void openApplication(String url) {
		driver.get(url);

	}

	/**
	 * This method is used to initialize the action class
	 */
	public void intiallizeActions() {
		action = new Actions(driver);
	}

	/**
	 * This method is used to MouseHover on element
	 * 
	 * @parameter element
	 */
	public void mouseHoverOnElement(WebElement element) {
		action.moveToElement(element).perform();
	}

	/**
	 * This method is used to perform right click action on current mouse location
	 * 
	 * @parameter element
	 */
	public void rightClickAction(WebElement element) {
		action.contextClick(element).perform();
	}

	/**
	 * this method is used to close particular Browser
	 */
	public void closeBrowser() {
		driver.quit();
	}

	/**
	 * this method is used to close particular Tab
	 */
	public void closeTab() {
		driver.close();
	}

	/**
	 * This method is used to convert the String to long data type
	 * @param stringData
	 * @return
	 */
	public long convertStringToLong(String stringData) {
		return Long.parseLong(stringData);
	}
	
	/**
	 * This method is used to switch frame based on index
	 * 
	 * @parameter index
	 */
	public void switchFrame(int index) {
		driver.switchTo().frame(index);
	}

	/**
	 * This method is used to switch frame based on webElement address
	 * 
	 * @parameter index
	 */
	public void switchFrame(WebElement element) {
		driver.switchTo().frame(element);

	}

	/**
	 * This method is used to switch frame based on name or id
	 * 
	 * @parameter index
	 */
	public void switchFrame(String nameOrID) {
		driver.switchTo().frame(nameOrID);
	}
	/**
	 * This method is used to back to web page 
	 * @parameter ""
	 */
	public void backWebpage() {
		driver.navigate().back();
	}
	/**
	 * This method is used to refresh the web page
	 * @parameter ""
	 */
	public void reloadThePage() {
		driver.navigate().refresh();
		threadWait(3000);
	}

	/**
	 * This method is used to handle <select> tag Drop down by using value attribute
	 * of the <options> tag
	 * 
	 * @parameter value
	 * @parameter dropDownElement
	 */
	public void handleSelectDropdown(String value, WebElement dropDownElement) {
		Select select = new Select(dropDownElement);
		select.selectByValue(value);
	}

	/**
	 * This method is used to handle <select> tag Drop down by using index
	 * 
	 * @parameter value
	 * @parameter dropDownElement
	 */
	public void handleSelectDropdown(WebElement dropDownElement, int indexNumber) {
		Select select = new Select(dropDownElement);
		select.selectByIndex(indexNumber);
	}

	/**
	 * This method is used to handle <select> tag Drop down by using VisibleText
	 * 
	 * @parameter value
	 * @parameter dropDownElement
	 */
	public void handleSelectDropdown(WebElement dropDownElement, String visibleText) {
		Select select = new Select(dropDownElement);
		select.selectByVisibleText(visibleText);
	}
	
	/**
	 * The method is used to initialize the Actions class
	 */
	public void initializeAction() {
		action=new Actions(driver);
		
	}
	/**
	 * This method is used to maximize the browser
	 */
	public void maximizeBrowser() {
		driver.manage().window().maximize();
	}

	/**
	 * This method is used to take the current page screen shot
	 * 
	 * @parameter currentClass
	 * @parameter javaUtility
	 */
	public void takeScreenShotPage(Object currentClass, JavaUtility javaUtility) {

		TakesScreenshot ts = (TakesScreenshot) driver;
		File tempFile = ts.getScreenshotAs(OutputType.FILE);
		File permaFile = new File("./errorshots/" + currentClass.getClass().getSimpleName() + "_"
				+ javaUtility.getCurrentDate("dd_MM_yyyy_HH_mm_sss") + ".png");

		try {
			FileUtils.copyFile(tempFile, permaFile);
		} catch (IOException e) {
			e.printStackTrace();

		}
	}

	/**
	 * This Method is used to take the particular element screen shot
	 * 
	 * @parameter element
	 * @parameter currentClass
	 * @parameter javaUtility
	 */
	public void takeScreenShotElement(WebElement element, Object currentClass, JavaUtility javaUtility) {

		File tempFile = element.getScreenshotAs(OutputType.FILE);
		File permaFile = new File("./elementScreenShots/" + currentClass.getClass().getSimpleName() + ""
				+ javaUtility.getCurrentDate("dd_MM_yyyy_HH_mm_sss") + ".png");

		try {
			FileUtils.copyFile(tempFile, permaFile);
		} catch (IOException e) {
			e.printStackTrace();

		}
	}

	/**
	 * This method will wait till the element is click able(Custom wait)
	 * 
	 * @parameter totalDuration
	 * @parameter pollingTime
	 * @parameter element
	 */
	public void waitTillElementClickable(int totalDuration, long pollingTime, WebElement element) {

		int currentTime = 10;

		while (currentTime <= totalDuration) {
			try {
				element.click();
				break;
			} catch (Exception e) {
				try {
					Thread.sleep(1000);

				} catch (Exception e1) {
					e1.printStackTrace();
				}

			}

		}
	}
	
	/**
	 * This method will wait till the element is click able(Custom wait)
	 * 
	 * @parameter totalDuration Time in Second
	 * @parameter element
	 */
	public void waitElementToBeClickable(WebElement element, Duration timeInSeconds) {
		WebDriverWait waitToClick = (new WebDriverWait(driver, timeInSeconds));
		try {
			waitToClick.until(ExpectedConditions.elementToBeClickable(element));
		} catch (TimeoutException t) {
			waitToClick.until(ExpectedConditions.elementToBeClickable(element));
		}
	}

	/**
	 * This method is used to initialize the ExplicitWait or web driver wait
	 * 
	 * @parameter timeOuts
	 * @parameter pollingTime
	 */
	public void intiallizeExplicitWait(long timeOuts, long pollingTime) {

		wait = new WebDriverWait(driver, Duration.ofSeconds(timeOuts));
		wait.pollingEvery(Duration.ofMillis(pollingTime));
		wait.ignoring(Exception.class);
	}

	/**
	 * This method is used to wait until element is visible
	 * 
	 * @parameter element
	 */
	public void waitTillElementVisible(WebElement element) {
		wait.until(ExpectedConditions.visibilityOf(element));
	}
	
	/**
	 * This method is used to wait until element is visible
	 * 
	 * @parameter locator
	 * @parameter driver
	 * @parameter timeoutInSeconds
	 */
	public  void waitForElement(WebDriver driver, By locator, Duration timeoutInSeconds) {
        WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds);
        wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

	/**
	 * This method is used to wait until element is visible
	 * 
	 * @parameter element
	 */
	public void waitTillElementInVisible(WebElement element) {

		wait.until(ExpectedConditions.invisibilityOf(element));
	}

	/**
	 * This method is used to accept the java script pop-up/confirmation pop-up/alert pop-up
	 * @parameter ""
	 */
	public void jsPopupaccept() {

		driver.switchTo().alert().accept();
	}

	/**
	 * This method is used to Dismiss the java script pop-up/confirmation pop-up/alert pop-up
	 * @parameter ""
	 */
	public void jsPopupdecline() {

		driver.switchTo().alert().dismiss();
	}

	/**
	 * This method is used to send the java script pop-up/confirmation pop-up/alert pop-up
	 * 
	 * @parameter data
	 */
	public void jsPopupSendData(String data) {

		driver.switchTo().alert().sendKeys(data);
	}

	/**
	 * This method is used to fetch the data from the java script pop-up/confirmation
	 * pop-up/alert pop-up
	 */
	public void jsPopupGetText() {

		driver.switchTo().alert().getText();
	}

	/**
	 * This method is used to Window handles
	 * 
	 * @parameter partialText
	 * @parameter strategy
	 */
	public void switchWindow(String partialText, String strategy) {

		Set<String> winlds = driver.getWindowHandles();
		for (String id : winlds) {

			driver.switchTo().window(id);
			if (strategy.equalsIgnoreCase("url")) {

				if (driver.getCurrentUrl().contains(partialText)) {
					break;
				}
			} else if (strategy.equalsIgnoreCase("title")) {
				if (driver.getTitle().contains(partialText)) {
					break;
				}
			}
		}
	}
	
	/*
	 * This method is used to wait the script until time given.
	 * @Parameter millis
	 */
	public static void threadWait(long millis) {
		try {
			Thread.sleep(millis);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	/*
	 * This method is used to load the page content.
	 * @Paramter driver
	 */
	public static String getPageContent(WebDriver driver) {
		threadWait(2000);
		return driver.findElement(By.tagName("html")).getText();
	}
	
	/*
	 * This method is use to wait, to load the page content
	 * @Parameter driver
	 * @Parameter text
	 * @Parameter time
	 */
	public static void waitForPageToContainText(WebDriver driver, String text, Duration time) {
		System.out.println("waiting for " + text + " on page");
		WebDriverWait wait = new WebDriverWait(driver, time);
		try {
			wait.until((WebDriver dr) -> dr.getPageSource().contains(text));
		} catch (JavascriptException e) {
			threadWait(2000);
		}
	}
	
	/*
	 * This method is use to not wait, to load the page content
	 * @Parameter driver
	 * @Parameter text
	 * @Parameter time
	 */
	public static void  waitForPageNotToContainText(WebDriver driver, String text, Duration time) {
		System.out.println("waiting for text \'" + text + "\' to disappear from the page");
		WebDriverWait wait = new WebDriverWait(driver, time);
		wait.until((WebDriver dr) -> !dr.getPageSource().contains(text));
	}
	
	/*
	 * This method is used to verify the containt by using Assert True method
	 * @Paramter actualValue
	 * @Paramter expectedValue
	 */
	public void verifyContains(String actualValue, String expectedValue) {
		String cropped = actualValue;
		if (actualValue.length() > 100) {
			cropped = actualValue.substring(0, 99) + "....";
		}
		Assert.assertTrue(actualValue.contains(expectedValue),
				String.format("Expected:\n'%s' to be in  \n" + "'%s'.", expectedValue, cropped));
	}

	/*
	 * This method is used for validation by using Assert true method.
	 * @parameter actualValue
	 * @parameter expectedValues
	 */
	public static void verifyContains(String actualValue, String... expectedValues) {
		for (String expectedValue : expectedValues) {
			Assert.assertTrue(actualValue.contains(expectedValue),
					String.format("Expected:\n'%s' to be in  \n" + "'%s'.", expectedValue, actualValue));
		}
	}
	/*
	 * This method is used to wait to load the page
	 * @Parameter driver
	 */
	public static void waitForPageLoad(WebDriver driver) {
		Boolean flag=false;
		int count=5;
		try {
			flag = new WebDriverWait(driver, Duration.ofSeconds(30)).until((ExpectedCondition<Boolean>) wd -> ((JavascriptExecutor) wd)
					.executeScript("return document.readyState").equals("complete"));
		} catch (Exception e) {
		}
		if (!flag&&count>0) {
			waitForPageLoad(driver);
			count--;
		}
	}
	/*
	 * This method is used to verify two value by Assert equals method.
	 * @Parameter actualValue
	 * @Paraemter expectedValue
	 */
	public static void verifyEquality(String actualValue, String expectedValue) {
		Assert.assertEquals(actualValue, expectedValue,
				String.format("Expected:\n'%s' but instead found \n" + "'%s'.", expectedValue, actualValue));
	}
	
	/*
	 * This method is used to capture url and titile to verify by using Assert Equals method
	 * @Parameter title
	 * @Parameter url
	 */
	public void validatePageTitleAndUrl(String title,String url) {
		threadWait(1500);
		Assert.assertEquals(driver.getTitle(), title);
		Assert.assertEquals(driver.getCurrentUrl(), url);
	}
	
	/*
	 * This method is used to capture the title and url for validation by using Assert equals method and close the tab 
	 * @Parameter title
	 * @Parameter url
	 */
	public void validatePageTitleAndUrlAndCloseTheTab(String title,String url) {
		threadWait(1500);
		Assert.assertEquals(driver.getTitle(), title);
		Assert.assertEquals(driver.getCurrentUrl(), url);
		closeTab();
	}
	
	/*
	 * This method is used to capture the title and partial url for validation and close the tab
	 * @Parameter title
	 * @Parameter url
	 */
	public void validatePageTitelAndPartialUrlAndCloseTheTab(String title,String url) {
		threadWait(1500);
		Assert.assertEquals(driver.getTitle(), title);
		verifyContains(driver.getCurrentUrl(), url);
		closeTab();
	}
	/*
	 * This method is used to wait to load the page.
	 * @Parameter driver
	 * 
	 */
	public static void waitForPageLoad(WebDriver driver, Duration timeInSeconds) {
		try {
			new WebDriverWait(driver, timeInSeconds).until((ExpectedCondition<Boolean>) wd -> ((JavascriptExecutor) wd)
					.executeScript("return document.readyState").equals("complete"));
		} catch (Exception e) {
		}
}

	

	

	

	
}
