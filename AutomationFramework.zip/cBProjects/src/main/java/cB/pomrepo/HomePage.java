package cB.pomrepo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cB.genericUtility.BaseClass;

public class HomePage extends BaseClass{

	WebDriver driver;
	
	public HomePage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//p[@class='styles_header__5oqTg']")
	private WebElement homePageValidationText;
	public String gethomePageValidationText() throws InterruptedException
	{
		Thread.sleep(3000);
		String homePageText = homePageValidationText.getText();
		return homePageText;
	}
	
	@FindBy( css ="li:nth-child(5)")
	private WebElement userModuleValidation;
	public String getuserModuleValidation() throws InterruptedException
	{
		Thread.sleep(3000);
		String userText = userModuleValidation.getText();
		return userText;
	}
	@FindBy(xpath = "//div[contains(@class,'styles_setting_logout')]/ul/li")
	private WebElement logoutButton;
	public WebElement getlogoutButton() throws InterruptedException
	{
		Thread.sleep(2000);
		return logoutButton;
	}
}
