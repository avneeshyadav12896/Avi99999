package cB.pomrepo;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cB.genericUtility.BaseClass;
import cB.genericUtility.FileUtility;

public class LoginPage extends BaseClass{

	WebDriver driver;
	
	public LoginPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	
	@FindBy(xpath ="//form[contains(@class,'styles_login_form')]/descendant::input[@name='login']")
	private WebElement emailTextField;
	public WebElement getEmailTextField() throws IOException {
		return emailTextField;
	}
	
	
	@FindBy(name="password")
	private WebElement passwordTextField;
	public WebElement getPasswordTextField() throws IOException {
		return passwordTextField;
	}
	@FindBy(xpath ="//button[@type='submit']")
	private WebElement loginButton;
	public void getLoginButton() {
		loginButton.click();
	}
	/*
	 * Login to the application with valid ce
	 */
	public void loginAction(String username,String password) throws IOException, InterruptedException {
		fileUtility=new FileUtility();
		Thread.sleep(2000);
		getEmailTextField().sendKeys(fileUtility.readDataFromPropertyFile("username"));
		Thread.sleep(2000);
		getPasswordTextField().sendKeys(fileUtility.readDataFromPropertyFile("password"));
		Thread.sleep(2000);
		getLoginButton();

	}
	/*
	 * Login to the application with invalid credential
	 */
	public void loginAction2(String username,String password) throws IOException, InterruptedException {
		fileUtility=new FileUtility();
		getEmailTextField().sendKeys(fileUtility.readDataFromPropertyFile("username2"));
		getPasswordTextField().sendKeys(fileUtility.readDataFromPropertyFile("password2"));
		getLoginButton();
	}

	@FindBy(xpath="//div[@class='validation-summary-errors']")
	private WebElement errorLoginValidation;
	public String geterrorLoginValidation() throws InterruptedException
	{
		Thread.sleep(4000);
		String errorText = errorLoginValidation.getText();
		return errorText;

	}
	
	@FindBy(xpath = "//div[@class='styles_left_form__oJzBQ']/descendant::p[contains(text(),'Login to Xley ')]")
	private WebElement loginPageValidation;
	public String getloginPageValidation() throws InterruptedException
	{
		Thread.sleep(4000);
		String text = loginPageValidation.getText();
		return text;
	}
}
