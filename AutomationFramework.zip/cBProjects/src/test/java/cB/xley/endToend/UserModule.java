package cB.xley.endToend;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import org.testng.annotations.Test;

import cB.genericUtility.BaseClass;

public class UserModule extends BaseClass{

	@Test
	public void userModuleValidation() throws IOException, InterruptedException
	{
		loginPage.loginAction(username, password);
		String text = homePage.getuserModuleValidation();
		Thread.sleep(2000);
		assertTrue(text.contains("Users"));
		homePage.getlogoutButton().click();
	}
}
