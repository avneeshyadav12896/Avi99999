package cB.xley.endToend;

import org.testng.annotations.Test;

import cB.genericUtility.BaseClass;

public class Methods extends BaseClass {
@Test
public void login()
	{
		System.out.println("login");
	}
@Test
public void signin()
{
	System.out.println("signin");
}
@Test
public void add()
{
	System.out.println("add");
}
@Test
public void sub()
{
	System.out.println(javaUtility.getFirstName());
	System.out.println(javaUtility.getRandomNumber());
	System.out.println(javaUtility.getRandomAadhaarNumber());
}

}
