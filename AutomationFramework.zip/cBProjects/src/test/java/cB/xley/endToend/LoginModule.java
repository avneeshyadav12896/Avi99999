package cB.xley.endToend;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import cB.genericUtility.BaseClass;


public class LoginModule extends BaseClass{

	
@Test(groups = "smoke")
public void login() throws IOException, InterruptedException
{
	loginPage.loginAction(username, password);
	homePage.getlogoutButton().click();
}
@Test
public void loginPagevalidation() throws IOException, InterruptedException
{
	String text = loginPage.getloginPageValidation();
	Thread.sleep(3000);
	Assert.assertTrue(text.contains("Login To Xley"));
	
	
}
@Test(groups = "smoke")
public void homePagevalidation() throws IOException, InterruptedException
{
	loginPage.loginAction(username, password );
	String text = homePage.gethomePageValidationText();
	Thread.sleep(3000);
	Assert.assertTrue(text.contains("Search For Influencers"));
	homePage.getlogoutButton().click();
}

@Test()
public void checkWebDriverElement()
{
	String string = javaUtility.generateRandomString(5);
	System.out.println(string);
	int number = javaUtility.randomNumber(10);
    System.out.println(number);
    System.out.println(javaUtility.randomMobileNumber());
    System.out.println(javaUtility.randomOTP6());
    System.out.println(javaUtility.randomOTP4());
    System.out.println(javaUtility.randomEmail());
}
}

